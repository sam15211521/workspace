from tkinter import *
from statistics import *

def find_mean(number):
    return mean(number)

def windows():
    
