from tkinter import *
window = Tk()
greeting = Label(window, text = "Hello, Tkinter")
greeting.pack()
window.mainloop()