from tkinter import *

root = Tk()

myLabel = Label(root, text = "Hello world")

myLabel.pack()

root.mainloop()