from tkinter import *
window = Tk()
greeting = Label(text ="Python rocks")
greeting.pack()
inputing = Entry()
inputing.pack()
window.mainloop()



